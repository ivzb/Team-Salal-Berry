<?php
include 'functions.php';
$title = "Контакти | GreenUni ..";
$description = "Greeuni контакти ";
$keywords = "контакт, адрес";

my_header($title, $description, $keywords);
?>
      <section>
         <div class="container">
             <div class="row long">
                 <div class="col-md-6">
                     <h2 class="top-distance">Контакти</h2>
                     <p class="indent">
                        Адресът на мейлинг листа е  <span class="emphasized important"> info МАЙМУНСКО 'а' green-uni.com [вместо "маймунско а" напишете @ :)]</span>. За да се запишете в него изпратете празен e-mail до <span class="emphasized important">  baceto МАЙМУНСКО 'а' green-uni.com</span>. Администраторът на листа <span class="emphasized important">[демек аз]</span> си запазва правото да изключва и да водя борба срещу абонатите неспазващи контекста на листа, спамещи с глупости и прочее.
                      </p>
                      <p class="indent">
                        Координатор <span class="emphasized important">“Прием на нови студенти” &#8594;</span>
                     </p>
                 </div>

                 <div class="col-md-6">
                     <img src="images/morpheus.jpg" class="right" alt="" />
                 </div>
             </div>

<!--              <hr> -->
         </div>
      </section>
<?php 
my_foother();
?>      